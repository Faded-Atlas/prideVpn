Thank you for downloading the GuardSec PrideVPN

please only use this for legal reasons and to hide you ip address during OP PrideFall

for android:

download the openvpn client on the play store which can be found here
https://play.google.com/store/apps/details?id=net.openvpn.openvpn

take the .ovpn file and import it into the app


for ios:

download the openvpn client on the app store which can be found here
https://apps.apple.com/us/app/openvpn-connect/id590379981

with the .ovpn import into the app

